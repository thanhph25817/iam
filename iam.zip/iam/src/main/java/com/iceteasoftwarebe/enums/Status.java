/**
 *
 */
package com.iceteasoftwarebe.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Chỉ định các trạng thái của user
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-08
 */
@Getter
@AllArgsConstructor
public enum Status {
    ACTIVE,
    INACTIVE,
    BLOCK
}

