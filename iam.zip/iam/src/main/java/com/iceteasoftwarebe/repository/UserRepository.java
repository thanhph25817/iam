package com.iceteasoftwarebe.repository;

import com.iceteasoftwarebe.entity.User;
import com.iceteasoftwarebe.config.cache.BusinessCacheConstants;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * User Repository
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-08
 */
@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    /**
     * Lấy thông tin user từ email
     */
    @Cacheable(cacheNames = BusinessCacheConstants.User.FIND_BY_EMAIL, key = "#email",
            unless = "#result == null")
    User findByEmail(String email);
}
