/**
 *
 */
package com.iceteasoftwarebe.controller;

import com.iceteasoftwarebe.dto.request.login.LoginRequest;
import com.iceteasoftwarebe.dto.response.common.ResponseObject;
import com.iceteasoftwarebe.dto.response.login.TokenResponse;
import com.iceteasoftwarebe.service.LoginService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Quá trình đăng nhập phân quyền
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-08
 */
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class LoginController {

    private final LoginService loginService;

    /**
     * Method dùng để gửi thông tin người dùng khi đăng nhập
     *
     * @param request
     * @param loginRequest
     */
    @PostMapping("/login")
    public ResponseEntity<ResponseObject<TokenResponse>> authorize(HttpServletRequest request,
                                                                   @RequestBody LoginRequest loginRequest) {

        return this.loginService.authorize(request, loginRequest);
    }
}
