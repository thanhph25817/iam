package com.iceteasoftwarebe.controller;

import com.iceteasoftwarebe.constant.Constants;
import com.iceteasoftwarebe.dto.request.signup.RegistrationRequest;
import com.iceteasoftwarebe.dto.request.signup.VerificationRequest;
import com.iceteasoftwarebe.dto.response.common.ResponseObject;
import com.iceteasoftwarebe.dto.response.signup.AuthenticationResponse;
import com.iceteasoftwarebe.service.RegisterService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

/**
 * The Google Authenticator Controller class receives human requests.
 *
 * @author vinhnv
 * @version 1.0
 * @since 2024-03-28
 */
@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@CrossOrigin("*")
public class RegisterController {

    private final RegisterService googleAuthenticatorService;

    /**
     * Points for registering new users with Google Authenticator.
     *
     * @param request The RegistrationRequest containing user information.
     * @return ResponseObject containing authentication.
     */
    @PostMapping("/register")
    public ResponseObject<AuthenticationResponse> registration(@RequestBody RegistrationRequest request) {
        return new ResponseObject<>(Constants.DEFAULT_MESSAGE_CREATE_SUCCESS, HttpStatus.CREATED.value(),
                LocalDateTime.now(), googleAuthenticatorService.registration(request));
    }

    /**
     * Points for verify code of User with TOTP authentication.
     *
     * @param request The RegistrationRequest containing user information.
     * @return ResponseObject containing status User.
     */
    @PostMapping("/register/verify-registration-totp")
    public ResponseObject<String> verifyCode(@RequestBody VerificationRequest request) {
        return new ResponseObject<>(Constants.DEFAULT_MESSAGE_SUCCESS_TOTP, HttpStatus.OK.value(),
                LocalDateTime.now(), googleAuthenticatorService.totpRegistrationVerify(request));
    }


}
