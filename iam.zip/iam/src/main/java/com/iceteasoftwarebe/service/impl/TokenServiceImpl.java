/**
 *
 */
package com.iceteasoftwarebe.service.impl;

import com.iceteasoftwarebe.service.TokenService;
import org.springframework.stereotype.Service;

/**
 * @author duongduc
 */
@Service
public class TokenServiceImpl implements TokenService {

}
