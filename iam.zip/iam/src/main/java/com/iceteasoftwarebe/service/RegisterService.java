package com.iceteasoftwarebe.service;

import com.iceteasoftwarebe.dto.request.signup.RegistrationRequest;
import com.iceteasoftwarebe.dto.request.signup.VerificationRequest;
import com.iceteasoftwarebe.dto.response.signup.AuthenticationResponse;

/**
 * The GoogleAuthenticatorService is the class interface to process
 * request of controller (authentication when user sign up).
 *
 * @author vinhnv
 * @version 1.0
 * @since 2024-03-28
 */
public interface RegisterService {

    /**
     * Get user creation information
     *
     * @param request
     * @return
     */
    AuthenticationResponse registration(RegistrationRequest request);

    /**
     * authenticate TOTP and update user status
     *
     * @param request
     * @return
     */
    String totpRegistrationVerify(VerificationRequest request);

}
