package com.iceteasoftwarebe.service.impl;

import com.iceteasoftwarebe.config.auth.TwoFactorAuthentication;
import com.iceteasoftwarebe.config.kafka.KafkaProducer;
import com.iceteasoftwarebe.constant.Constants;
import com.iceteasoftwarebe.constant.KafkaTopicConstant;
import com.iceteasoftwarebe.dto.request.signup.RegistrationRequest;
import com.iceteasoftwarebe.dto.request.signup.VerificationRequest;
import com.iceteasoftwarebe.dto.response.signup.AuthenticationResponse;
import com.iceteasoftwarebe.entity.User;
import com.iceteasoftwarebe.enums.ErrorCode;
import com.iceteasoftwarebe.enums.Status;
import com.iceteasoftwarebe.exception.handler.BadRequestAlertException;
import com.iceteasoftwarebe.repository.UserRepository;
import com.iceteasoftwarebe.service.RegisterService;
import com.iceteasoftwarebe.validator.Validator;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * The GoogleAuthenticatorService is the class to process logic to add User to the system
 * request of controller and authentication when User sign up
 *
 * @author vinhnv
 * @version 1.0
 * @since 2024-03-28
 */
@Service
@Transactional
@RequiredArgsConstructor
public class RegisterServiceImpl implements RegisterService {

    private final UserRepository userRepository;

    private final TwoFactorAuthentication twoFactorAuthentication;

    private final KafkaProducer kafkaProducer;

    /**
     * Adds a new user to the system based on the provided request.
     *
     * @param request The request containing information about the new user.
     *                This may include details such as email, password, full name, date of birth.
     * @return AuthenticationResponse containing the User ID and image url qr code to authentication.
     */
    @Override
    public AuthenticationResponse registration(RegistrationRequest request) {
        this.validateIdentity(request);
        User user = new User();

        User optionalUser = userRepository.findByEmail(request.getEmail());

        if (optionalUser != null) {
            String userStatus = optionalUser.getStatus();
            if (!Status.INACTIVE.name().equals(userStatus)) {
                throw new BadRequestAlertException(ErrorCode.MSG1002);
            }

            user.setId(optionalUser.getId());
        }

        user.setEmail(request.getEmail());
        user.setPassword(request.getPassword());
        user.setFullName(request.getFullName());
        user.setDateOfBirth(request.getDateOfBirth());
        user.setStatus(Status.INACTIVE.name());
        user.setSecretKey(twoFactorAuthentication.generateNewSecret());

        userRepository.save(user);
        kafkaProducer.sendMessage(KafkaTopicConstant.DEFAULT_KAFKA_TOPIC_SEND_EMAIL, user.getEmail());
        return new AuthenticationResponse(user.getId(), twoFactorAuthentication.generateQrCodeImageUri(user.getSecretKey()));
    }

    /**
     * Verification user to the system based on the provided request.
     *
     * @param request The request contains the user is TOTP credentials.
     *                This may include details such as id user and code TOTP.
     * @return Message Active User
     */
    @Override
    public String totpRegistrationVerify(VerificationRequest request) {

        if (request.getIdUser() == null) {
            throw new BadRequestAlertException(ErrorCode.MSG1013);
        }

        if (Validator.isNull(request.getCodeTOTP())) {
            throw new BadRequestAlertException(ErrorCode.MSG1013);
        }

        if (Validator.isTOTP(request.getCodeTOTP())
                || request.getCodeTOTP().length() != 6) {
            throw new BadRequestAlertException(ErrorCode.MSG1017);
        }

        User user = userRepository.findById(request.getIdUser())
                .orElseThrow(() -> new BadRequestAlertException(ErrorCode.MSG1002));

        if (Status.ACTIVE.name().equals(user.getStatus())) {
            throw new BadRequestAlertException(ErrorCode.MSG1001);
        }

        if (!twoFactorAuthentication.isTotpValid(user.getSecretKey(), request.getCodeTOTP())) {
            throw new BadRequestAlertException(ErrorCode.MSG1003);
        }

        user.setStatus(Status.ACTIVE.name());
        userRepository.save(user);
        return Constants.DEFAULT_MESSAGE_SUCCESS_TOTP;
    }

    /**
     * Validates the registration request.
     *
     * @param request The registration request to be validated.
     */
    private void validateIdentity(RegistrationRequest request) {

        // validate email
        if (Validator.isNull(request.getEmail())) {
            throw new BadRequestAlertException(ErrorCode.MSG1004);
        }

        if (Validator.isEmail(request.getEmail())
                || request.getEmail().length() > Constants.DEFAULT_EMAIL_LENGTH_MAX) {
            throw new BadRequestAlertException(ErrorCode.MSG1002);
        }

        // validate password
        if (Validator.isNull(request.getPassword())) {
            throw new BadRequestAlertException(ErrorCode.MSG1006);
        }

        if (Validator.isPassword(request.getPassword())
                || request.getPassword().length() < Constants.DEFAULT_PASSWORD_LENGTH_MIN
                || request.getPassword().length() > Constants.DEFAULT_PASSWORD_LENGTH_MAX) {
            throw new BadRequestAlertException(ErrorCode.MSG1004);
        }

        // validate full name
        if (Validator.isNull(request.getFullName())) {
            throw new BadRequestAlertException(ErrorCode.MSG1008);
        }

        if (com.iceteasoftwarebe.util.Validator.isVariableName(request.getFullName())
                || request.getFullName().length() > Constants.DEFAULT_FUllNAME_LENGTH_MAX) {
            throw new BadRequestAlertException(ErrorCode.MSG1009);
        }

        // validate date of birth
        if (com.iceteasoftwarebe.util.Validator.isNull(request.getDateOfBirth())) {
            throw new BadRequestAlertException(ErrorCode.MSG1010);
        }

        final long milliSeconds = System.currentTimeMillis();

        // date of birth không đc lớn hơn hiện tại
        if (request.getDateOfBirth().getTime() > milliSeconds) {
            throw new BadRequestAlertException(ErrorCode.MSG1012);
        }
    }
}
