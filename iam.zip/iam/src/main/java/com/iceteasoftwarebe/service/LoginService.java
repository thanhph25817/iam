package com.iceteasoftwarebe.service;

import com.iceteasoftwarebe.dto.request.login.LoginRequest;
import com.iceteasoftwarebe.dto.response.common.ResponseObject;
import com.iceteasoftwarebe.dto.response.login.TokenResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;

/**
 * Tầng service xử lí logic của user
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-10
 */
public interface LoginService {
    /**
     * Gửi request để login
     *
     * @param request
     * @param loginRequest
     */
    ResponseEntity<ResponseObject<TokenResponse>> authorize(HttpServletRequest request,
                                                            LoginRequest loginRequest);

}
