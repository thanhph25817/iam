package com.iceteasoftwarebe.service.impl;

import com.iceteasoftwarebe.constant.Constants;
import com.iceteasoftwarebe.dto.request.login.LoginRequest;
import com.iceteasoftwarebe.dto.response.common.ResponseObject;
import com.iceteasoftwarebe.dto.response.login.TokenResponse;
import com.iceteasoftwarebe.entity.User;
import com.iceteasoftwarebe.entity.UserLoginFailed;
import com.iceteasoftwarebe.entity.UserProperties;
import com.iceteasoftwarebe.enums.ErrorCode;
import com.iceteasoftwarebe.enums.Status;
import com.iceteasoftwarebe.exception.handler.BadRequestAlertException;
import com.iceteasoftwarebe.repository.UserLoginFailedRepository;
import com.iceteasoftwarebe.repository.UserRepository;
import com.iceteasoftwarebe.config.security.jwt.JWTAccessToken;
import com.iceteasoftwarebe.config.security.jwt.JWTToken;
import com.iceteasoftwarebe.config.security.jwt.JWTTokenProvider;
import com.iceteasoftwarebe.constant.SecurityConstants;
import com.iceteasoftwarebe.util.security.UserPrincipal;
import com.iceteasoftwarebe.service.LoginService;
import com.iceteasoftwarebe.util.GetterUtil;
import com.iceteasoftwarebe.util.Validator;
import jakarta.servlet.http.HttpServletRequest;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * @author duongduc
 * @version 1.0
 * @since 2024-04-10
 */
@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class LoginServiceImpl implements LoginService {

    private final UserRepository userRepository;

    private final UserLoginFailedRepository userLoginFailedRepository;

    private final PasswordEncoder passwordEncoder;

    @Getter
    private final UserProperties userProperties;

    private final JWTTokenProvider<UserPrincipal> jwtTokenProvider;

    /**
     * Phân quyền user khi đăng nhập
     */
    @Override
    public ResponseEntity<ResponseObject<TokenResponse>> authorize(HttpServletRequest request,
                                                                   LoginRequest loginRequest) {

        String email = GetterUtil.getString(loginRequest.getEmail());
        String password = GetterUtil.getString(loginRequest.getPassword());

        // Check email có để trống k
        if (Validator.isNull(email)) {
            throw new BadRequestAlertException(ErrorCode.MSG1003);
        }

        // Check email có đúng định dạng k
        if (com.iceteasoftwarebe.validator.Validator.isEmail(loginRequest.getEmail())
                || loginRequest.getEmail().length() > Constants.DEFAULT_EMAIL_LENGTH_MAX) {
            throw new BadRequestAlertException(ErrorCode.MSG1002);
        }

        // Check password có để trống k
        if (Validator.isNull(password)) {
            throw new BadRequestAlertException(ErrorCode.MSG1001);
        }

        // Check password có đúng định dạng k
        if (com.iceteasoftwarebe.validator.Validator.isPassword(loginRequest.getPassword())
                || loginRequest.getPassword().length() < Constants.DEFAULT_PASSWORD_LENGTH_MIN
                || loginRequest.getPassword().length() > Constants.DEFAULT_PASSWORD_LENGTH_MAX) {
            throw new BadRequestAlertException(ErrorCode.MSG1004);
        }

        User user = this.findByEmail(email);

        // Check tài khoản có bị block k
        if (Validator.equals(Status.BLOCK.name(), user.getStatus())) {
            throw new BadRequestAlertException(ErrorCode.MSG1006);
        }

        // Check tài khoản đã được active chưa
        if (Validator.equals(Status.INACTIVE.name(), user.getStatus())) {
            throw new BadRequestAlertException(ErrorCode.MSG1007);
        }

        UserLoginFailed userLoginFailed = this.userLoginFailedRepository.findByUserId(user.getId());

        // kiểm tra xem có đang bị tạm khóa không
        if (Validator.isNotNull(userLoginFailed) && Validator.isNotNull(userLoginFailed.getUnlockTime())
                && userLoginFailed.getUnlockTime().isAfter(LocalDateTime.now())) {
            throw new BadRequestAlertException(ErrorCode.MSG1025);
        }

        // Check password
        if (!passwordEncoder.matches(password, user.getPassword())) {
            this.updateLoginAttempts(userLoginFailed, false);

            throw new BadRequestAlertException(ErrorCode.MSG1008);
        }

        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(email, password);
        SecurityContextHolder.getContext().setAuthentication(authenticationToken);

        boolean rememberMe = loginRequest.getRememberMe() != null && loginRequest.getRememberMe();

        JWTAccessToken accessToken = this.jwtTokenProvider.createAccessToken(email, rememberMe);

        JWTToken refreshToken = this.jwtTokenProvider.createRefreshToken(email);

        TokenResponse tokenResponse = TokenResponse.builder()//
                .type(SecurityConstants.Header.BEARER_START.trim())
                .csrfToken(accessToken.getCsrfToken().getToken())
                .refreshToken(refreshToken.getToken())
                .csrfTokenDuration(accessToken.getCsrfToken().getDuration())
                .build();

        // clear login fail attempt
        this.updateLoginAttempts(userLoginFailed, true);

        HttpCookie accessCookie = this.jwtTokenProvider.createHttpCookie(SecurityConstants.Cookie.ACCESS_TOKEN,
                accessToken.getAccessToken().getToken(), accessToken.getAccessToken().getDuration());

        HttpCookie rememberMeCookie = this.jwtTokenProvider.createHttpCookie(SecurityConstants.Cookie.REMEMBER_ME,
                String.valueOf(rememberMe), accessToken.getAccessToken().getDuration());

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.SET_COOKIE, accessCookie.toString());
        httpHeaders.add(HttpHeaders.SET_COOKIE, rememberMeCookie.toString());

        ResponseObject<TokenResponse> data = new ResponseObject<>(Constants.DEFAULT_MESSAGE_SUCCESS,
                HttpStatus.OK.value(), LocalDateTime.now(), tokenResponse);

        return new ResponseEntity<>(data, httpHeaders, HttpStatus.OK);
    }

    /**
     * @param userLoginFailed
     * @param success
     */
    private void updateLoginAttempts(UserLoginFailed userLoginFailed, boolean success) {
        if (success) {
            // clear login failed attempts
            userLoginFailed.setUnlockTime(null);
            userLoginFailed.setLoginFailedAttempts(0);
        } else {
            int loginFailedAttempts = userLoginFailed.getLoginFailedAttempts() + 1;

            userLoginFailed.setLoginFailedAttempts(loginFailedAttempts);

            if (this.userProperties.getLoginAttempts() > 0
                    && loginFailedAttempts >= this.userProperties.getLoginAttempts()) {
                userLoginFailed.setUnlockTime(
                        LocalDateTime.now().plusMinutes(this.userProperties.getLoginFailedLockDuration()));
            }
        }

        this.userLoginFailedRepository.save_(userLoginFailed);
    }

    /**
     * Lấy thông tin user bằng email
     */
    private User findByEmail(String email) {
        User user = this.userRepository.findByEmail(email);
        if (user == null) {
            throw new BadRequestAlertException(ErrorCode.MSG1004);
        }

        return user;
    }
}
