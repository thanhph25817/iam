package com.iceteasoftwarebe.entity;

import com.iceteasoftwarebe.entity.common.AuditTable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Thông tin lưu lại khi user đăng nhập không thành công
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-11
 */
@Data
@NoArgsConstructor
@Entity
@Table
@EqualsAndHashCode(callSuper = false)
public class UserLoginFailed extends AuditTable {

	private static final long serialVersionUID = 4482834111410590241L;

	/**
	 * @param userId
	 */
	public UserLoginFailed(Integer userId) {
		super();
		this.userId = userId;
	}

	@Id
	@Column(name = "user_id", length = 19)
	private Integer userId;

	@Column(name = "login_failed_attempts", length = 2)
	private int loginFailedAttempts;

	@Column(name = "unlock_time")
	private LocalDateTime unlockTime;
}
