/**
 * 
 */
package com.iceteasoftwarebe.entity;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Thông tin thuộc tính thêm của user
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-11
 */
@Data
@Component
@ConfigurationProperties(prefix = "user")
public class UserProperties {
	private int preRegisterVerifyLimit;

	private int loginAttempts;

	private int loginFailedLockDuration;

	private int resetPwVerifyLimit;

	private int changePwVerifyLimit;
	
	private int pwDuplicatedLimit;

	private int ekycMinImages;

	private int ekycMaxImages;
	
	private int pwDuration;
	
	private int[] pwExpiredNoticeBefore;
	
	private String defaultBranchCode;
	
	private String smsDefaultLanguage;
	
	private int idCardIssueDateLessThan;
	
	private int passportIssueDateLessThan;
	
	private int pwVerifyFailedLimit;
	
	private String defaultIssuePlace;
	
	private String defaultPlacecOfResidence;
}
