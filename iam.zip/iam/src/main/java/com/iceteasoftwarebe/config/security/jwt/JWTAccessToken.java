package com.iceteasoftwarebe.config.security.jwt;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * Các field của AccessToken
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-08
 */
@Data
@Builder
public class JWTAccessToken implements Serializable{

	private static final long serialVersionUID = 2271652818578387603L;

	private JWTToken accessToken;
    
    private JWTToken csrfToken;
}
