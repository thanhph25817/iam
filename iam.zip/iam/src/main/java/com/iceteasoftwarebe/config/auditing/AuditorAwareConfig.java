package com.iceteasoftwarebe.config.auditing;

import org.springframework.data.domain.AuditorAware;

import java.util.Optional;

/**
 * This class retrieves the ID of the current user as the auditor.
 *
 * @author vinhnv
 * @version 1.0
 * @since 2024-03-28
 */
public class AuditorAwareConfig implements AuditorAware<Integer> {

    @Override
    public Optional<Integer> getCurrentAuditor() {
        return Optional.of(1);
    }
}

