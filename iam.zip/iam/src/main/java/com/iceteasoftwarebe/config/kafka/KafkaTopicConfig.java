package com.iceteasoftwarebe.config.kafka;

import com.iceteasoftwarebe.constant.KafkaTopicConstant;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class KafkaTopicConfig {
    @Bean
    public NewTopic topicSendEmail(){
        return TopicBuilder
                .name(KafkaTopicConstant.DEFAULT_KAFKA_TOPIC_SEND_EMAIL)
                .partitions(5)
                .build();
    }

    @Bean
    public NewTopic topicNotifications(){
        return TopicBuilder
                .name(KafkaTopicConstant.DEFAULT_KAFKA_TOPIC_NOTIFICATIONS)
                .partitions(5)
                .build();
    }
}
