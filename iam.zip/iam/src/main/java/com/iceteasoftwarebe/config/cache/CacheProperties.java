package com.iceteasoftwarebe.config.cache;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * @author duongduc
 * @version 1.0
 * @since 2024-04-10
 */
@Configuration
@ConfigurationProperties(prefix = "cache")
@Getter
@Setter
public class CacheProperties {

    private Map<String, Integer> timeToLives;

    private String configType;
}
