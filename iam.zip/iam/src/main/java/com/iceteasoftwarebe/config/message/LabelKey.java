package com.iceteasoftwarebe.config.message;

/**
 * 01/06/2021 - LinhLH: Create new
 *
 * @author LinhLH
 */
public interface LabelKey {
    public static final String ERROR_ACCOUNT_DOES_NOT_EXIST = "error.account-does-not-exist";
    public static final String ERROR_ACCOUNT_DOES_EXIST = "error.account-does-exist";
    public static final String ERROR_TOTP_IS_INCORRECT_OR_HAS_EXPIRED = "error.otp-is-incorrect-or-has-expired";
    public static final String ERROR_EMAIL_IS_EMPTY = "error.email-is-empty";
    public static final String ERROR_EMAIL_IS_INVALID = "error.email-is-invalid";
    public static final String ERROR_PASSWORD_IS_EMPTY = "error.password-is-empty";
    public static final String ERROR_PASSWORD_IS_INVALID = "error.password-is-invalid";
    public static final String ERROR_FULL_NAME_IS_EMPTY = "error.full-name-is-empty";
    public static final String ERROR_FULL_NAME_IS_INVALID = "error.full-name-is-invalid";
    public static final String ERROR_DATE_OF_BIRTH_IS_EMPTY = "error.date-of-birth-is-empty";
    public static final String ERROR_DATE_OF_BIRTH_IS_INVALID = "error.date-of-birth-is-invalid";
    public static final String ERROR_DOB_GREATER_THAN_NOW = "error.dob-greater-than-now";
    public static final String ERROR_ID_USER_NOT_EMPTY = "error.id-user-not-empty";
    public static final String ERROR_TOTP_NOT_EMPTY = "error.totp-not-empty";
    public static final String ERROR_TOTP_IS_INVALID = "error.totp-is-invalid";
    public static final String ERROR_INTERNAL_SERVER = "error.internal-server";
    public static final String ERROR_INVALID_EMAIL_OR_PASSWORD = "error.invalid-email-or-password";
    public static final String ERROR_INVALID_TOKEN = "error.invalid-token";
    public static final String ERROR_TOKEN_MALFORMED = "error.token-malformed";
    public static final String ERROR_TOKEN_HAS_EXPIRED = "error.token-has-expired";
    public static final String ERROR_JWT_TOKEN_IS_UNSUPPORTED = "error.jwt-token-is-unsupported";
    public static final String ERROR_ACCOUNT_IS_BLOCK = "error.account-has-been-blocked";
    public static final String ERROR_ACCOUNT_IS_INACTIVE = "error.account-is-inactive";
    public static final String ERROR_PASSWORD_IS_WRONG = "error.password-is-wrong";
    public static final String ERROR_YOUR_ACCOUNT_HAS_BEEN_TEMPORARILY_LOCKED = "error.your-account-has-been-temporarily-locked";
}
