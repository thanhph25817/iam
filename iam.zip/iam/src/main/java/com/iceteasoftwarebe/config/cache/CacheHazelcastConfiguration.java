package com.iceteasoftwarebe.config.cache;

import com.hazelcast.config.Config;
import com.hazelcast.config.ManagementCenterConfig;
import com.hazelcast.config.MapConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.iceteasoftwarebe.constant.CacheConstants;
import com.iceteasoftwarebe.constant.EnvConstants;
import com.iceteasoftwarebe.util.Validator;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.env.Profiles;

import java.util.Map;

/**
 * @author duongduc
 * @version 1.0
 * @since 2024-04-10
 */
@Slf4j
@Getter
@Setter
@Configuration(value = "cacheHazelcastConfiguration")
@EnableCaching
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "cache", name = "config-type", havingValue = "hazelcast", matchIfMissing = false)
public class CacheHazelcastConfiguration implements DisposableBean {

	@Value("${cache.hazelcast.localIp}")
    private String localIp;

	@Value("${cache.hazelcast.remoteIp}")
    private String remoteIp;

	@Value("${cache.hazelcast.backup-count}")
    private int backupCount;

	@Value("${cache.hazelcast.instanceName}")
    private String instanceName;

    private ManagementCenter managementCenter;
    
    @Getter
    @Setter
    @NoArgsConstructor
    public static class ManagementCenter {
		@Value("${cache.hazelcast.management-center.enabled}")
        private boolean enabled;

		@Value("${cache.hazelcast.management-center.update-interval}")
        private int updateInterval;

		@Value("${cache.hazelcast.management-center.url}")
        private String url;
    }
    
	private final Environment env;

	private final CacheProperties properties;
	
	@Override
	public void destroy() throws Exception {
		log.info("Closing Cache Manager");

		Hazelcast.shutdownAll();
	}

	@Bean
	public CacheManager cacheManager(HazelcastInstance hazelcastInstance) {
		log.info("Starting HazelcastCacheManager");

		return new com.hazelcast.spring.cache.HazelcastCacheManager(hazelcastInstance);
	}

	@Bean
	public HazelcastInstance hazelcastInstance() {
		log.info("Configuring Hazelcast");

		HazelcastInstance hazelCastInstance = Hazelcast.getHazelcastInstanceByName(this.getInstanceName());

		if (hazelCastInstance != null) {
			log.info("Hazelcast already initialized");

			return hazelCastInstance;
		}

		Map<String, Integer> timeToLives = this.properties.getTimeToLives();

		Config config = new Config();

		config.setInstanceName(this.getInstanceName());
		config.getNetworkConfig().setPort(5704);
		config.getNetworkConfig().setPortAutoIncrement(true);
		// In development, remove multicast auto-configuration
		System.setProperty("hazelcast.local.localAddress", this.getLocalIp());

		if (env.acceptsProfiles(Profiles.of(EnvConstants.Profile.DEVELOPMENT))) {
			config.getNetworkConfig().getJoin().getAwsConfig().setEnabled(false);
			config.getNetworkConfig().getJoin().getMulticastConfig().setEnabled(false);
			config.getNetworkConfig().getJoin().getTcpIpConfig().setEnabled(true).addMember(this.getRemoteIp());
		} else {
			config.getNetworkConfig().getJoin().getAwsConfig().setEnabled(false);
			config.getNetworkConfig().getJoin().getMulticastConfig().setEnabled(false);
			config.getNetworkConfig().getJoin().getTcpIpConfig().setEnabled(false);
		}

		config.setManagementCenterConfig(initializeDefaultManagementCenterConfig());

		for (Map.Entry<String, Integer> entry : timeToLives.entrySet()) {
			String key = entry.getKey();
			Integer timeTolive = entry.getValue();

			log.info("Add cache with name {} and time to live {} seconds", key, timeTolive);
			
			config.getMapConfigs().put(key,
					Validator.equals(key, CacheConstants.Others.DEFAULT) ? initializeDefaultMapConfig(timeTolive)
							: initializeMapConfig(timeTolive));

		}

		return Hazelcast.newHazelcastInstance(config);
	}

	private ManagementCenterConfig initializeDefaultManagementCenterConfig() {

        return new ManagementCenterConfig();
	}

	private MapConfig initializeDefaultMapConfig(Integer timeToLive) {
		MapConfig mapConfig = new MapConfig();
		/*
		 * Number of backups. If 1 is set as the backup-count for example, then all entries of the map will
		 * be copied to another JVM for fail-safety. Valid numbers are 0 (no backup), 1, 2, 3.
		 */
		mapConfig.setBackupCount(this.getBackupCount());

		if (Validator.isNotNull(timeToLive)) {
			mapConfig.setTimeToLiveSeconds(timeToLive);
		}

		return mapConfig;
	}

	private MapConfig initializeMapConfig(Integer timeToLive) {
		MapConfig mapConfig = new MapConfig();

		if (Validator.isNotNull(timeToLive)) {
			mapConfig.setTimeToLiveSeconds(timeToLive);
		}

		return mapConfig;
	}
}
