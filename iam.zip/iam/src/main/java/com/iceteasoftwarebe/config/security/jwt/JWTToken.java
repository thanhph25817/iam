package com.iceteasoftwarebe.config.security.jwt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Các field của Token
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-08
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JWTToken implements Serializable{

	private static final long serialVersionUID = 6079085501370429127L;

	private String token;
    
    private int duration;
    
    public JWTToken(String token) {
    	this.token = token;
    }
}
