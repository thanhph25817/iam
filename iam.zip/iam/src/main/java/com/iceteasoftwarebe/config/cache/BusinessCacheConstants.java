/**
 *
 */
package com.iceteasoftwarebe.config.cache;

import com.iceteasoftwarebe.constant.CacheConstants;

/**
 * @author duongduc
 * @version 1.0
 * @since 2024-04-10
 */
public interface BusinessCacheConstants extends CacheConstants {

    public interface User {
        public static final String FIND_BY_EMAIL = "user_findByEmail";
    }
}
