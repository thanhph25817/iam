/**
 * 
 */
package com.iceteasoftwarebe.config.cache;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.jsontype.BasicPolymorphicTypeValidator;
import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
import com.iceteasoftwarebe.constant.CacheConstants;
import com.iceteasoftwarebe.util.Validator;
import io.lettuce.core.ClientOptions;
import io.lettuce.core.resource.DefaultClientResources;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.cache.RedisCacheManagerBuilderCustomizer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext.SerializationPair;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author duongduc
 * @version 1.0
 * @since 2024-04-10
 */
@Slf4j
@Getter
@Setter
@Configuration(value = "cacheRedisConfiguration")
@EnableCaching
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "cache", name = "config-type", havingValue = "redis", matchIfMissing = true)
public class CacheRedisConfiguration {
	private String mode;

	private int cacheDuration;

	private Standalone standalone;

	private Sentinel sentinel;

	private LettucePool lettucePool;
	
	@Getter
	@Setter
	private static class Standalone {
		private int port;

		private String password;

		private String host;
	}
	
	@Getter
	@Setter
	private static class Sentinel {
		private int port;

		private String password;

		private String master;

		private List<String> nodes;
	}

	@Getter
	@Setter
	private static class LettucePool {

		private long shutdownTimeout;
		
		private long commandTimeout;
		
		private int minIdle;
		
		private int maxIdle;
		
		private long maxWaitMillis;
		
		private int maxTotal;
	}
	
	public static enum Mode {
		STANDALONE, SENTINEL
	}
	
	private final CacheProperties properties;
	
	@Bean
	public RedisConnectionFactory redisConnectionFactory() {

		LettuceConnectionFactory lettuceConnectionFactory = null;

		GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();

		poolConfig.setMaxIdle(this.lettucePool.getMinIdle());
        poolConfig.setMinIdle(this.lettucePool.getMinIdle());
        poolConfig.setMaxWaitMillis(this.lettucePool.getMaxWaitMillis());
        poolConfig.setMaxTotal(this.lettucePool.getMaxTotal());
		
        // @formatter:off
        ClientOptions clientOptions = ClientOptions.builder()
        		.disconnectedBehavior(ClientOptions.DisconnectedBehavior.REJECT_COMMANDS)
                .autoReconnect(true)
                .build();
        
		LettucePoolingClientConfiguration lettuceConfiguration = LettucePoolingClientConfiguration.builder()
				.commandTimeout(Duration.ofMillis(this.lettucePool.getCommandTimeout()))
				.shutdownTimeout(Duration.ofMillis(this.lettucePool.getShutdownTimeout()))
				.clientOptions(clientOptions)
				.clientResources(DefaultClientResources.create())
				.poolConfig(poolConfig)
				.build();
		// @formatter:on
		
		if (Validator.equals(this.mode, Mode.STANDALONE.name().toLowerCase())) {
			RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();

			redisStandaloneConfiguration.setHostName(this.standalone.getHost());
			redisStandaloneConfiguration.setPort(this.standalone.getPort());
			redisStandaloneConfiguration.setPassword(RedisPassword.of(this.standalone.getPassword()));

			lettuceConnectionFactory =
					new LettuceConnectionFactory(redisStandaloneConfiguration, lettuceConfiguration);
		} else {
			RedisSentinelConfiguration sentinelConfig =
					new RedisSentinelConfiguration().master(this.sentinel.getMaster());

			this.sentinel.getNodes().forEach(s -> sentinelConfig.sentinel(s, this.sentinel.getPort()));

			if (Validator.isNotNull(this.sentinel.getPassword())) {
				sentinelConfig.setPassword(this.sentinel.getPassword());
				sentinelConfig.setSentinelPassword(this.sentinel.getPassword());
			}

			lettuceConnectionFactory = new LettuceConnectionFactory(sentinelConfig, lettuceConfiguration);

		}

		return lettuceConnectionFactory;
	}

	@Bean("redisTemplate")
	RedisTemplate<String, String> redisTemplate() throws Exception {
		final StringRedisTemplate template = new StringRedisTemplate(redisConnectionFactory());

		Jackson2JsonRedisSerializer<Object> jackson2JsonRedisSerializer =
				new Jackson2JsonRedisSerializer<Object>(Object.class);

		ObjectMapper om = this.createObjectMapper();

		jackson2JsonRedisSerializer.setObjectMapper(om);

		RedisSerializer<String> stringSerializer = new StringRedisSerializer();

		template.setKeySerializer(stringSerializer);
		template.setValueSerializer(jackson2JsonRedisSerializer);

		template.setHashKeySerializer(stringSerializer);
		template.setHashValueSerializer(jackson2JsonRedisSerializer);

		return template;
	}

	@Bean
    public RedisCacheConfiguration cacheConfiguration() {
        return RedisCacheConfiguration.defaultCacheConfig().entryTtl(Duration.ofMinutes(this.cacheDuration))
                        .disableCachingNullValues()
                        .serializeValuesWith(SerializationPair
                                        .fromSerializer(new GenericJackson2JsonRedisSerializer(createObjectMapper())));
    }

	@Bean
    public RedisCacheManagerBuilderCustomizer redisCacheManagerBuilderCustomizer() {
        Map<String, Integer> timeTolives = this.properties.getTimeToLives();

        return (builder) -> {
        	Map<String, RedisCacheConfiguration> configurationMap = new HashMap<>();
        	
            for (Map.Entry<String, Integer> entry : timeTolives.entrySet()) {
                String key = entry.getKey();
                Integer timeTolive = entry.getValue();

				configurationMap.put(key,
						RedisCacheConfiguration.defaultCacheConfig().entryTtl(Duration.ofSeconds(timeTolive)));
            }

			configurationMap.put(CacheConstants.Others.DEFAULT,
					RedisCacheConfiguration.defaultCacheConfig().entryTtl(Duration.ofMinutes(this.cacheDuration)));
            
            builder.withInitialCacheConfigurations(configurationMap);
        };
    }
	
//    @Primary
//    @Bean
//    public CacheManager cacheManager() {
//        RedisCacheManager.RedisCacheManagerBuilder builder =
//                        RedisCacheManager.builder(redisConnectionFactory())
//                                        .cacheDefaults(cacheConfiguration());
//
//        RedisCacheManager cacheManager = builder.build();
//
//        return cacheManager;
//    }

    private ObjectMapper createObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();

        PolymorphicTypeValidator ptv =
                        BasicPolymorphicTypeValidator.builder()
                        .allowIfSubType(Map.class)
                        .allowIfSubType(List.class)
                        .allowIfSubType(Number.class)
                        .allowIfSubType("com.its.training")
                        .allowIfSubTypeIsArray()
                        .build();
        
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        
        objectMapper.findAndRegisterModules();
        
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);

        objectMapper.activateDefaultTyping(ptv, ObjectMapper.DefaultTyping.NON_FINAL);

        return objectMapper;
    }
}
