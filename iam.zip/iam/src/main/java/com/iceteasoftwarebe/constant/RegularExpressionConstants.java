package com.iceteasoftwarebe.constant;

public interface RegularExpressionConstants {

    public static final String DEFAULT_REGEXP_EMAIL = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";
    public static final String DEFAULT_REGEXP_PASSWORD = "^(?=.*[A-Z])(?=.*[a-z])(?=.*[^A-Za-z0-9]).*$";
    public static final String DEFAULT_REGEXP_TOTP = "[0-9]+";


}
