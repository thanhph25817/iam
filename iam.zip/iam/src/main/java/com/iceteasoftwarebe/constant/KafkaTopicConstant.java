package com.iceteasoftwarebe.constant;

public interface KafkaTopicConstant {

    public static final String DEFAULT_KAFKA_TOPIC_SEND_EMAIL = "Topic_SendEmail";
    public static final String DEFAULT_KAFKA_TOPIC_NOTIFICATIONS = "Topic_1";
}
