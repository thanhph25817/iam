package com.iceteasoftwarebe.constant;

/**
 * @author duongduc
 * @version 1.0
 * @since 2024-04-10
 */
public interface CacheConstants {
    public interface Others {
        public static final String DEFAULT = "default";
    }
    
    public static final String KEY = "key";
}
