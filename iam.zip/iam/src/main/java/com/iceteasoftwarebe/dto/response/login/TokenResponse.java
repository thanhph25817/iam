package com.iceteasoftwarebe.dto.response.login;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.iceteasoftwarebe.annotation.Exclude;
import com.iceteasoftwarebe.dto.response.common.Response;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * Thông tin token trả về ở response
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-08
 */
@Getter
@Setter
@Builder
@JsonInclude(Include.NON_NULL)
public class TokenResponse extends Response {

    private static final long serialVersionUID = 79507724976661349L;

    @Exclude
    private String csrfToken;

    @Exclude
    private String refreshToken;

    private String type;

    private Integer csrfTokenDuration;

    private Integer refreshTokenDuration;
}
