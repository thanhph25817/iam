package com.iceteasoftwarebe.dto.request.login;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.iceteasoftwarebe.annotation.Exclude;
import com.iceteasoftwarebe.dto.request.common.Request;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Thông tin người dùng ở request
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-08
 */
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoginRequest extends Request {
    /** The Constant serialVersionUID */
    private static final long serialVersionUID = -8340388451714375195L;

    private String email;

    @Exclude
    private String password;

    private Boolean rememberMe;

    @Override
    public String toString() {
        return "LoginRequest{" + "email='" + this.email + '\'' + ", rememberMe=" + this.rememberMe + '}';
    }
}
