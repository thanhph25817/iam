package com.iceteasoftwarebe.dto.request.signup;

import lombok.Getter;
import lombok.Setter;

/**
 * Represents a verification request containing user ID and TOTP code.
 *
 * @author vinhnv
 * @version 1.0
 * @since 2024-03-28
 */
@Setter
@Getter
public class VerificationRequest {

    private Integer idUser;

    private String codeTOTP;
}
