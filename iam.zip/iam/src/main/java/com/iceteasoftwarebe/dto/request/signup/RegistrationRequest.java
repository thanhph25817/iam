package com.iceteasoftwarebe.dto.request.signup;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * Represents a registration request containing user information.
 *
 * @author vinhnv
 * @version 1.0
 * @since 2024-03-28
 */
@Setter
@Getter
public class RegistrationRequest {

    private String email;

    private String password;

    private String fullName;

    private Date dateOfBirth;
}
