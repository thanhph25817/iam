package com.iceteasoftwarebe.dto.request.common;

import lombok.Getter;
import lombok.Setter;

/**
 * The PaginationRequest is the class define value of page and pageSize
 *
 * @author duongduc1520
 * @version 1.0
 * @since 2024-03-26
 */
@Setter
@Getter
public class PaginationRequest {

    public static final String DEFAULT_PAGE = "0";
    public static final String DEFAULT_PAGE_SIZE = "10";

}
