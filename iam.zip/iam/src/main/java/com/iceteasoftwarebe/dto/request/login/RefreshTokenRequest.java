/**
 * 
 */
package com.iceteasoftwarebe.dto.request.login;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.iceteasoftwarebe.dto.request.common.Request;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Dùng để làm mới token ở request
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-08
 */
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RefreshTokenRequest extends Request {

	private static final long serialVersionUID = 4764667734408786739L;
	
	private String refreshToken;

}
