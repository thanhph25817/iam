/**
 *
 */
package com.iceteasoftwarebe.dto.response.common;

import java.io.Serializable;

/**
 * Base response được xây dựng cho các thuộc tính chung của response
 *
 * @author duongduc
 * @version 1.0
 * @since 2024-04-08
 */
public abstract class Response implements Serializable {

    private static final long serialVersionUID = -1431837812667487546L;

}
