package com.iceteasoftwarebe.dto.response.signup;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The AuthenticationResponse is a class to define properties of response
 * when containing user ID and image URL.
 *
 * @author vinhnv
 * @version 1.0
 * @since 2024-03-28
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AuthenticationResponse {

    private int idUser;

    private String imageUrl;
}
