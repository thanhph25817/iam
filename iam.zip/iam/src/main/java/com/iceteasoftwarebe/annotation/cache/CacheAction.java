package com.iceteasoftwarebe.annotation.cache;

/**
 * @author duongduc
 * @version 1.0
 * @since 2024-04-10
 */
public enum CacheAction {
    PUT,

    EVICT
}
