package com.iceteasoftwarebe.annotation.cache;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author duongduc
 * @version 1.0
 * @since 2024-04-10
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface CacheCollection {

    /**
     * The cache names which have used in @Cacheable
     */
    String[] cacheNames();

    /**
     * The key of cache which have used in @Cacheable
     */
    String key();

    /**
     * The properties have been used to compare 2 objects to find out the object will be update. If nothing to
     * be found, it means the new instance has created and it will be added to the cache.
     *
     * @return
     */
    String[] compareProperties();

    /**
     * The condition has been checked before update the cache. The condition uses Spring Expression Language (SpEL)
     */
    String condition() default "";

    CacheAction action() default CacheAction.PUT;
}
