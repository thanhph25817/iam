package com.iceteasoftwarebe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IceTeaSoftwareBeApplication {
    public static void main(String[] args) {
        SpringApplication.run(IceTeaSoftwareBeApplication.class, args);
    }
}
